<?php
namespace Pronamespace\Controllers;
use Pronamespace\Models\Usuario;
use Pronamespace\Views\Usuario\UsuarioView;
class UsuarioController
{
    public function mostrarUsuario($nombre, $email)
{
    $usuario = new Usuario($nombre, $email);
    $usuarioView = new UsuarioView();
    $usuarioView->mostrar($usuario);
}
}

