<?php
namespace Pronamespace\Views\Usuario;

use Pronamespace\Views\Usuario;

class UsuarioView{
    public function mostrar(Usuario $usuario){
        echo "Nombre: " . $usuario->getNombre() . "<br>";
        echo "Email". $usuario->getEmail() . "<br>";
}
}