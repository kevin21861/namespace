<?php
class QuickSort{
  public function quickSort($arr){
    //Caso base: Si la lista tiene 0 a 1 elementos, está ordenada.
    $length = count($arr);
    if ($length <= 1) {
        return $arr;
    }
    // Elegir un pivote (en este caso, el ultimo del arreglo)
    $pivot = $arr[$length - 1];

    // Participar el arreglo en elementos menores y mayores que el pivote
    $left = []; //definir array
    $right = []; //definir array
    for ($i=0; $i < $length - 1; $i++) { 
        if ($arr[$i] < $pivot) {
            $left[] = $arr[$i];
        } else{
            $right[] = $arr[$i];
        }
    }

    //Aplicar Quickshort de manera recursiva en las dos particiones
    $left = $this->quickSort($left);
    $right = $this->quickSort($right);

    // Combinar los resultados
    return array_merge($left, [$pivot], $right);
}
   
}
// Ejemplo de uso
$lista = [65,44,2,5,88,9,7,2];
$quickSort = new QuickSort();
$resultado = $quickSort->quickSort($lista);

echo "Lista ordenada: ";
foreach ($resultado as $valor){
    echo $valor." ";
}